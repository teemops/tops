<?php echo e($slot); ?>

<?php /**PATH /home/ben/dev/saas/app/vendor/laravel/framework/src/Illuminate/Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>