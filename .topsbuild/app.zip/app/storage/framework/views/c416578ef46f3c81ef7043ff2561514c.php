<?php echo e($slot); ?>: <?php echo e($url); ?>

<?php /**PATH /home/ben/dev/saas/app/vendor/laravel/framework/src/Illuminate/Mail/resources/views/text/button.blade.php ENDPATH**/ ?>